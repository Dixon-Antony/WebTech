
var webinars = [];
var workshops = [];
var sharedName;

var app = angular.module('tcesquare', []);

app.service('myService', function() {
    this.web = webinars;
    this.work = workshops;
    this.sharedData = sharedName;
});

app.directive('myDirective', function(searchFor) {
    return {
        template: '<p>Showing results for {{searchFor}}</p>'
    }
});

app.controller('myController', function($scope, $http ,myService) {
    
    $http.get('/web').then(function(data) {
        $scope.webinars = data.data;
    });

    //$scope.webinars = myService.web;
    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

    // $scope.display=false;

});

app.controller('myController2', function($scope, myService,$http) {

    $http.get('/work').then(function(data) {
        $scope.workshops = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

});


app.controller('myController3',function($scope,$http){

    $http.get('/userData').then(function(data){
        $scope.userData = data.data;
    });

    $scope.share = function(name){
        sharedName = name;
    }

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };



 
});

app.controller('myController4',function($scope,myService) { 

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };
    
});