const Service = require('node-windows').Service
const svc =new Service({
    name:'NodeeServer',
    description: 'Events management System',
    script:"D:\\Engg-2019-2023\\Programming\\Angular\\Projects\\Events MK2\\index.js"
});

svc.on('install',function(){
    svc.start()
})

svc.install()