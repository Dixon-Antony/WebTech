
var webinars = [
    { 'name': 'Dixon', 'date': '12/9/21', 'venue': 'Tce', 'time': '9:00 AM' },
    { 'name': 'Sreesh', 'date': '10/9/21', 'venue': 'Tce', 'time': '10:00 AM' },
    { 'name': 'Ragul', 'date': '11/10/21', 'venue': 'Tce', 'time': '11:00 AM' },
];

var workshops = [
    { 'name': 'Dixon', 'date': '12/9/21', 'venue': 'Tce', 'time': '9:00 AM' },
    { 'name': 'Sreesh', 'date': '10/9/21', 'venue': 'Tce', 'time': '10:00 AM' },
    { 'name': 'Ragul', 'date': '11/10/21', 'venue': 'Tce', 'time': '11:00 AM' },
];

var app = angular.module('tcesquare', []);

app.service('myService', function() {
    this.web = webinars;
    this.work = workshops;
});

app.directive('myDirective', function(searchFor) {
    return {
        template: '<p>Showing results for {{searchFor}}</p>'
    }
});

app.controller('myController', function($scope, $http, myService) {
    
    $http.get('/web').then(function(data) {
        $scope.webinars = data.data;
    });

    //$scope.webinars = myService.web;
    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

    // $scope.display=false;

});

app.controller('myController2', function($scope, myService,$http) {

    $http.get('/work').then(function(data) {
        $scope.workshops = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

});


app.controller('myController3',function($scope,$http){
    $http.get('/all').then(function(data){
        $scope.allData = data.data;
    });
});