
var webinars = [];
var workshops = [];

var registered = [];
var updateData = [];

var app = angular.module('tcesquare', []);


app.service('myService', function() {
    this.web = webinars;
    this.work = workshops;
});


app.directive('myDirective', function(searchFor) {
    return {
        template: '<p>Showing results for {{searchFor}}</p>'
    }
});


app.controller('myController', function($scope, $http ,myService) {
    
    $http.get('/web').then(function(data) {
        $scope.webinars = data.data;
    });

    //$scope.webinars = myService.web;
    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

    // $scope.display=false;

});


app.controller('myController2', function($scope, myService,$http) {

    $http.get('/work').then(function(data) {
        $scope.workshops = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

});


app.controller('myController3',function($scope,$http){

    $http.get('/userData').then(function(data){
        $scope.userData = data.data;
    });

        $http.get('/studentData').then(function(data){
        $scope.studentData = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    }; 
});


app.controller('myController4',function($scope,$http) {

    $http.post('/update').then(function(data) {
        $scope.updateData = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };
    
});


app.controller('myController5',function($scope,$http) { 

    $http.post('/registered').then(function(data){
        $scope.registered = data.data;
        if($scope.registered.length==0){
            $scope.showx=true;
        }
        else{
            $scope.real=true;
        }
    });
    
});