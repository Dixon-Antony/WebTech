const express = require("express");
const bodyparser = require("body-parser");
const cors = require("cors");
const sql = require("mysql2");

const app = express();

var name;

app.use(express.static('img'));
app.use(express.static('script'));
app.use(express.static('styles'));
app.use(cors());
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));

// database connection

const db = sql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'events',
    port: '3306'
});

db.connect(err => {
    if (err) {
        console.log(err, 'Db error !!!');
    }
    console.log("Database Connected...");
});


app.get('/web', (req, res) => {
    let qr = `SELECT * FROM webinars`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Webinars selection error');
        }
        var webinars = result;
        res.send(webinars);
    });
});

app.get('/webi', (req, res) => {
    let qr = `SELECT name FROM webinars`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Webinars Name selection error');
        }
        var webinarsName = result;
        res.send(webinarsName);
    });
});


app.get('/work', (req, res) => {
    let qr = `SELECT * FROM workshops`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Workshops selection error');
        }
        var workshops = result;
        res.send(workshops);
    });
});

app.get('/', function(req, res) {
    res.sendFile(`${__dirname}/home.html`);
});

app.get('/webinars', (req, res) => {
    res.sendFile(`${__dirname}/webinars.html`);

});

app.post('/webinars', (req, res) => {

    let eventName = req.body.eventName;
    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `INSERT INTO webinars(name,venue,date,time) VALUES ('${eventName}','${venue}','${date}','${time}')`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Insertion Error');
        }
        // res.send({
        //     message:"Webinar inserted successfully",
        //     data:result
        // });
        res.redirect('/webinars');
    });

});


app.get('/workshops', (req, res) => {
    res.sendFile(`${__dirname}/workshops.html`)
});

app.post('/workshops', (req, res) => {

    let eventName = req.body.eventName;
    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `INSERT INTO workshops SET name='${eventName}',venue='${venue}',date='${date}',time='${time}'`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Insertion Error');
        }
        // res.send({
        //     message:"Worshop inserted successfully",
        //     data:result
        // });
        res.redirect('/workshops');
    });

});

app.get('/workshops', (req, res) => {
    res.sendFile(`${__dirname}/workshops.html`)
});



app.get('/update', function(req, res) {
    name = req.query.name;
    res.sendFile(`${__dirname}/update.html`);
});

app.post('/update', (req, res) => {
    
    // let eventName = req.body.eventName;
    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `UPDATE webinars SET venue='${venue}',date='${date}',time='${time}' WHERE name='${name}'`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Updation Error');
        }
        // res.send({
        //     message:"Worshop inserted successfully",
        //     data:result
        // });
        res.redirect('/webinars');
    });

});




// get all data from db

// app.get('/user', (req, res) => {
//     console.log("Retrieving data...");

//     let qr = `SELECT * FROM users`;
//     db.query(qr, (err, result) => {
//         if (err) {
//             conole.log(err, 'Query error !!!    ');
//         }
//         if (result.length > 0) {
//             res.send({
//                 message: "User data",
//                 data: result
//             });
//         }
//     });

// });


// // get a single user data from db

// app.get('/user/:id', (req, res) => {
//     console.log('Accessing user-id:', req.params.id);
//     let userid = req.params.id;
//     let qr = `SELECT * FROM users WHERE id = ${userid}`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, 'Query error for single data !!!');
//         }
//         if (result.length > 0) {
//             res.send({
//                 message: "Single data",
//                 data: result
//             });
//         } else {
//             res.send({
//                 message: "Data not found"
//             });
//         }
//     });

// });


// // post data

// app.post('/user', (req, res) => {
//     console.log(req.body, 'createUser');

//     let username = req.body.name;
//     let email = req.body.email;
//     let pass = req.body.password;

//     let qr = `INSERT INTO users(name,email,password) VALUES('${username}','${email}','${pass}')`

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, "Post error !!!");
//         }
//         res.send({
//             message: "Data inserted successfully"
//         });
//     });

// });


// //update data

// app.put('/user/:id', (req, res) => {
//     console.log(req.body, 'updateUser');

//     let userid = req.params.id;
//     let username = req.body.name;
//     let email = req.body.email;
//     let pass = req.body.password;

//     let qr = `UPDATE users SET name='${username}',email='${email}',password='${pass}' WHERE id=${userid}`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, 'Updation error !!!');
//         }
//         res.send({
//             message: "Record updated successfully"
//         });
//     });

// });


// //delete data

// app.delete('/user/:id', (req, res) => {
//     console.log(req.body, 'deleteUser');

//     let userid = req.params.id;

//     let qr = `DELETE FROM users WHERE id='${userid}'`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, "Deletion error !!!");
//         }
//         res.send({
//             message: "Record deleted successfully"
//         });
//     });

// });


app.listen(3000, () => {
    console.log("Server listening on Port 3000...");
});