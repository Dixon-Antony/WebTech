// var webinars = [
//     { 'name': 'Dixon', 'id': 1, 'venue': 'Tce', 'time': '9:00 AM' },
//     { 'name': 'Sreesh', 'id': 2, 'venue': 'Tce', 'time': '10:00 AM' },
//     { 'name': 'Ragul', 'id': 3, 'venue': 'Tce', 'time': '11:00 AM' }
// ];

// var app = angular.module('tcesquare', []);

// app.service('myService', function() {
//     this.web = webinars;
// });

// app.directive('myDirective', function(searchFor) {
//     return {
//         template: '<p>Showing results for {{searchFor}}</p>'
//     }
// });

// app.factory('myFactory', function() {

//     var y = function() {
//         this.web = webinars;
//         if (web.length >= 5) {
//             return true;
//         } else {
//             return false;
//         }
//     };
//     return y

// });

// app.factory('random', function() {
//             var randomObject = {};
//             var number = true;
//             randomObject.generate = function() {
//                 return number;
//             };
//             return randomObject;
//         });

// app.controller('myController', function($scope, myService, myFactory, random) {
//     $scope.webinars = myService.web;
//     $scope.isVisible = false;
//     $scope.updown = 'down';
//     $scope.showHide = function() {
//         $scope.isVisible = $scope.isVisible ? false : true;
//         $scope.updown = 'up';
//     };


//     $scope.addEvent = function() {
//         if ($scope.addName ==null){
//             $scope.display = true;
//         }else{
//             $scope.display = false;
//             $scope.webinars.push({ 'name': $scope.addName, 'id': $scope.addId, 'venue': $scope.addVenue, 'time': $scope.addTime });
//             $scope.addName = null;
//             $scope.addId = null;
//             $scope.addVenue = null;
//             $scope.addTime = null;

//         }
//     };

//     $scope.removeEvent = function(a) {
//         webinars.splice(a, 1);
//     };

// //    $scope.display = random.generate();

// });






// app.controller('myController2', function($scope, myService) {
//     $scope.webinars = myService.web;
//     $scope.isVisible = false;
//     $scope.updown = 'down';
//     $scope.showHide = function() {
//         $scope.isVisible = $scope.isVisible ? false : true;
//         $scope.updown = 'up';
//     };

//     $scope.addEvent = function() {
//         if ($scope.addName == "" || $scope.addId == "" || $scope.addVenue == "" || $scope.addTime == "") {

//         }
//         $scope.webinars.push({ 'name': $scope.addName, 'id': $scope.addId, 'venue': $scope.addVenue, 'time': $scope.addTime });
//         $scope.addName = "";
//         $scope.addId = "";
//         $scope.addVenue = "";
//         $scope.addTime = "";
//         $scope.x = "";
//     };

//     $scope.removeEvent = function(a) {
//         webinars.splice(a, 1);
//     };

// });

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var webinars = [
    { 'name': 'Dixon', 'date': '12/9/21', 'venue': 'Tce', 'time': '9:00 AM' },
    { 'name': 'Sreesh', 'date': '10/9/21', 'venue': 'Tce', 'time': '10:00 AM' },
    { 'name': 'Ragul', 'date': '11/10/21', 'venue': 'Tce', 'time': '11:00 AM' },
];

var workshops = [
    { 'name': 'Dixon', 'date': '12/9/21', 'venue': 'Tce', 'time': '9:00 AM' },
    { 'name': 'Sreesh', 'date': '10/9/21', 'venue': 'Tce', 'time': '10:00 AM' },
    { 'name': 'Ragul', 'date': '11/10/21', 'venue': 'Tce', 'time': '11:00 AM' },
];

var app = angular.module('tcesquare', []);

app.service('myService', function() {
    this.web = webinars;
    this.work = workshops;
});

app.directive('myDirective', function(searchFor) {
    return {
        template: '<p>Showing results for {{searchFor}}</p>'
    }
});

app.factory('myFactory', function() {
    var y = function() {
        this.web = webinars;
        if (web.length >= 4) {
            return true;
        } else {
            return false;
        }
    }
    return y

});

app.factory('myFactory2', function() {
    var y = function() {
        this.work = workshops;
        if (work.length >= 4) {
            return true;
        } else {
            return false;
        }
    }
    return y

});

app.controller('myController', function($scope, $http, myService, myFactory) {
    
    $http.get('/web').then(function(data) {
        $scope.webinars = data.data;
    });

    //$scope.webinars = myService.web;
    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

    // $scope.display=false;

    $scope.addEvent = function() {
        if ($scope.addName == "" || $scope.addName == null || $scope.addDate == "" || $scope.addDate == null || $scope.addVenue == "" || $scope.addVenue == null || $scope.addTime == "" || $scope.addTime == null) {
            $scope.display = true;
        } else {
            $scope.display = false;
            $scope.webinars.push({ 'name': $scope.addName, 'date': $scope.addDate, 'venue': $scope.addVenue, 'time': $scope.addTime });
            $scope.addName = "";
            $scope.addDate = "";
            $scope.addVenue = "";
            $scope.addTime = "";
            $scope.x = "";
        }
    };

    $scope.removeEvent = function(a) {
        webinars.splice(a, 1);
    };

    $scope.display = myFactory();

});

app.controller('myController2', function($scope, myService, myFactory2, $http) {

    $http.get('/work').then(function(data) {
        $scope.workshops = data.data;
    });

    $scope.isVisible = false;
    $scope.updown = 'down';
    $scope.showHide = function() {
        $scope.isVisible = $scope.isVisible ? false : true;
        $scope.updown = 'up';
    };

    $scope.addEvent = function() {
        if ($scope.addName == "" || $scope.addName == null || $scope.addDate == "" || $scope.addDate == null || $scope.addVenue == "" || $scope.addVenue == null || $scope.addTime == "" || $scope.addTime == null) {
            $scope.display = true;

        } else {
            $scope.display = false;
            $scope.workshops.push({ 'name': $scope.addName, 'date': $scope.addDate, 'venue': $scope.addVenue, 'time': $scope.addTime });
            $scope.addName = "";
            $scope.addDate = "";
            $scope.addVenue = "";
            $scope.addTime = "";
            $scope.x = "";
        }
    };

    $scope.removeEvent = function(a) {
        workshops.splice(a, 1);
    };

    $scope.display = myFactory2();

});