const express = require("express");
const bodyparser = require("body-parser");
const cookieParser = require("cookie-parser");
const cors = require("cors");
const sql = require("mysql2");
const alert = require("alert");
const session  = require('express-session');
const url = require('url');

const app = express();

var name;
var id;
var category;
var eventX;

app.use(cookieParser());
app.use(express.static('img'));
app.use(express.static('script'));
app.use(express.static('styles'));
app.use(cors());
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: false }));

// app.use(session({
//     secret:'key that signs the cookie',
//     resave:false,
//     saveUninitialized:false
// }))

// database connection

const db = sql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'events',
    port: '3306'
});

db.connect(err => {
    if (err) {
        console.log(err, 'Db error !!!');
    }
    console.log("Database Connected...");
});

//////
//////Data Sent to Frontend
//////

app.get('/web', (req, res) => {
    let qr = `SELECT * FROM webinars`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Webinars selection error');
        }
        var webinars = result;
        res.send(webinars);
    });
});

app.get('/work', (req, res) => {
    let qr = `SELECT * FROM workshops`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Workshops selection error');
        }
        var workshops = result;
        res.send(workshops);
    });
});

app.get('/userData', (req, res) => {
    let qrid = req.cookies.user_id;
    let qr = `SELECT webinars.* FROM webinars WHERE webinars.user_id='${qrid}' UNION SELECT workshops.* FROM workshops WHERE workshops.user_id='${qrid}'`;
    db.query(qr, (err, result) => {
        if (err) {
            console.log(err, 'Union selection error');
        }
        var userData = result;
        res.send(userData);
    });
});

//////
////// Get APIs
//////


app.get('/', function(req, res) {

    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        res.sendFile(`${__dirname}/home.html`);
    }
    else{
        res.redirect('/login');
    }
});


app.get('/webinars', (req, res) => {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        res.sendFile(`${__dirname}/webinars.html`);
    }
    else{
        res.redirect('/login');
    }
});


app.get('/workshops', (req, res) => {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        res.sendFile(`${__dirname}/workshops.html`)
    }
    else{
        res.redirect('/login');
    }
});


app.get('/update', function(req, res) {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        name = req.query.name;
        category = req.query.category;
        res.sendFile(`${__dirname}/update.html`);
    }
    else{
        res.redirect('/login');
    }
});


app.get('/delete', function(req, res) {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        name = req.query.name;
        category = req.query.category;

        let qr = `DELETE FROM ${category} WHERE name='${name}'`;
        db.query(qr, (err, result) => {
            if (err) {
                console.log('Deletion Error',err);
            }
            res.sendFile(`${__dirname}/profile.html`);
        });

    }
    else{
        res.redirect('/login');
    }
});


app.get('/login', function(req, res) {
    res.clearCookie('user_id');
    res.clearCookie('name');
    res.sendFile(`${__dirname}/login.html`);
});


app.get('/profile', function(req, res) {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        res.sendFile(`${__dirname}/profile.html`);
    }
    else{
        res.redirect('/login');
    }
});


app.get('/registered', function(req, res) {
    if(req.cookies.user_id!=undefined || req.cookies.name!=undefined){
        eventX = req.query.name; 
        res.sendFile(`${__dirname}/registered.html`);
    }
    else{
        res.redirect('/login');
    }
});


app.get('/logout',(req,res)=>{
    res.clearCookie('user_id');
    res.clearCookie('name');
    res.redirect('/login');
});

//////
////// Post APIs
//////

app.post('/registered',(req,res)=>{

    let eventName = eventX;
    let qr = `SELECT * FROM registered WHERE eventName='${eventName}'`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Registered Data Error',err);
        }
        res.send(result);
    });
});


app.post('/webinars', (req, res) => {

    let user_id = req.cookies.user_id;
    let eventName = req.body.eventName;
    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `INSERT INTO webinars(user_id,name,venue,date,time,category) VALUES ('${user_id}',${eventName}','${venue}','${date}','${time}','webinars')`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Insertion Error');
        }
        // res.send({
        //     message:"Webinar inserted successfully",
        //     data:result
        // });
        res.redirect('/webinars');
    });

});


app.post('/workshops', (req, res) => {

    let user_id = req.cookies.user_id;
    let eventName = req.body.eventName;
    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `INSERT INTO workshops SET user_id='${user_id}',name='${eventName}',venue='${venue}',date='${date}',time='${time}',category='workshops'`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Insertion Error');
        }
        res.redirect('/workshops');
    });

});


app.post('/update', (req, res) => {

    let eventName = name;
    let eventCategory = category;

    let venue = req.body.venue;
    let date = req.body.date;
    let time = req.body.time;

    let qr = `UPDATE ${eventCategory} SET venue='${venue}',date='${date}',time='${time}' WHERE name='${eventName}'`;

    db.query(qr, (err, result) => {
        if (err) {
            console.log('Updation Error',err);
        }
        res.redirect('/profile');
    });

});


app.post('/register', (req, res) => {

    let txt = req.body.txt;
    let email = req.body.email;
    let password = req.body.password;

    let qr2 = `SELECT * FROM users WHERE name='${txt}' OR email='${email}' OR password='${password}'`

    db.query(qr2, (err, result) => {
        if (err) throw err;
        if (result.length >= 1) {
            alert('The User already exists');
            res.redirect('/login');
        }
        else {
            let qr = `INSERT INTO users(name,email,password) VALUES ('${txt}','${email}','${password}')`;

            db.query(qr, (err, result) => {
                if (err) {
                    console.log('Registration error');
                }
                else{
                res.cookie('name',txt);
                res.redirect('/');
                }
            });
        }
    });
});


app.post('/login', (req, res) => {

    let email = req.body.eml;
    let password = req.body.pswd;

    let qr2 = `SELECT * FROM users WHERE email='${email}' AND password='${password}'`

    db.query(qr2, (err, result) => {
        if (err) throw err;
        if (result.length == 1) {
            res.cookie('user_id',result[0].id);
            res.redirect('/');
        }
        else {
            alert('Username or password is incorrect');
            res.redirect('/login');

        }
    });
});



// get all data from db

// app.get('/user', (req, res) => {
//     console.log("Retrieving data...");

//     let qr = `SELECT * FROM users`;
//     db.query(qr, (err, result) => {
//         if (err) {
//             conole.log(err, 'Query error !!!    ');
//         }
//         if (result.length > 0) {
//             res.send({
//                 message: "User data",
//                 data: result
//             });
//         }
//     });

// });


// // get a single user data from db

// app.get('/user/:id', (req, res) => {
//     console.log('Accessing user-id:', req.params.id);
//     let userid = req.params.id;
//     let qr = `SELECT * FROM users WHERE id = ${userid}`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, 'Query error for single data !!!');
//         }
//         if (result.length > 0) {
//             res.send({
//                 message: "Single data",
//                 data: result
//             });
//         } else {
//             res.send({
//                 message: "Data not found"
//             });
//         }
//     });

// });


// // post data

// app.post('/user', (req, res) => {
//     console.log(req.body, 'createUser');

//     let username = req.body.name;
//     let email = req.body.email;
//     let pass = req.body.password;

//     let qr = `INSERT INTO users(name,email,password) VALUES('${username}','${email}','${pass}')`

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, "Post error !!!");
//         }
//         res.send({
//             message: "Data inserted successfully"
//         });
//     });

// });


// //update data

// app.put('/user/:id', (req, res) => {
//     console.log(req.body, 'updateUser');

//     let userid = req.params.id;
//     let username = req.body.name;
//     let email = req.body.email;
//     let pass = req.body.password;

//     let qr = `UPDATE users SET name='${username}',email='${email}',password='${pass}' WHERE id=${userid}`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, 'Updation error !!!');
//         }
//         res.send({
//             message: "Record updated successfully"
//         });
//     });

// });


// //delete data

// app.delete('/user/:id', (req, res) => {
//     console.log(req.body, 'deleteUser');

//     let userid = req.params.id;

//     let qr = `DELETE FROM users WHERE id='${userid}'`;

//     db.query(qr, (err, result) => {
//         if (err) {
//             console.log(err, "Deletion error !!!");
//         }
//         res.send({
//             message: "Record deleted successfully"
//         });
//     });

// });


app.listen(3000, () => {
    console.log("Server listening on Port 3000...");
});